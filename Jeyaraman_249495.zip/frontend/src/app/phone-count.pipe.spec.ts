import { PhoneCountPipe } from './phone-count.pipe';

describe('PhoneCountPipe', () => {
  it('create an instance', () => {
    const pipe = new PhoneCountPipe();
    expect(pipe).toBeTruthy();
  });
});
