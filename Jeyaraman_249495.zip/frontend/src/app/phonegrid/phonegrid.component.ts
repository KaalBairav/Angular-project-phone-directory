import { Component, OnInit } from '@angular/core';
import { PhoneStoreService } from '../services/phone-store.service';
import { Phones } from '../models/phones';

@Component({
  selector: 'app-phonegrid',
  templateUrl: './phonegrid.component.html',
  styleUrls: ['./phonegrid.component.css']
})
export class PhonegridComponent implements OnInit {
  phone: Phones[];
  constructor(private bsss:PhoneStoreService) { 
    this.phone = [];
  }

  ngOnInit() {
    //this.books = this.bsss.getBooks();
    this.bsss.getPhone().subscribe(
      (data) => {
        this.phone = data;
      }
    );
  }

}