import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { PhoneStoreService } from '../services/phone-store.service';


@Component({
  selector: 'app-phonedelete',
  templateUrl: './phonedelete.component.html',
  styleUrls: ['./phonedelete.component.css']
})
export class PhonedeleteComponent implements OnInit {
 
   cId:number;
  constructor(private actRtr:ActivatedRoute, 
    private bsss: PhoneStoreService,
    private router: Router) { }

  ngOnInit() {
    this.actRtr.params.subscribe(
      (params) => {
        this.cId = params.cId;
      }
    );
  }

  delete(){
    this.bsss.deleteById(this.cId).subscribe(
      (resp) =>{
        this.router.navigateByUrl("/");
      }
    );
  }

}
