import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PhonedeleteComponent } from './phonedelete.component';

describe('PhonedeleteComponent', () => {
  let component: PhonedeleteComponent;
  let fixture: ComponentFixture<PhonedeleteComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PhonedeleteComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PhonedeleteComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
