import { Component, OnInit } from '@angular/core';
import { PhoneStoreService } from '../services/phone-store.service';
import { Phones } from '../models/phones';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {

  phone: Phones[];
  constructor(private bsss:PhoneStoreService) { 
    this.phone = [];
  }


  ngOnInit() {
    //this.books = this.bsss.getBooks();
    this.bsss.getPhone().subscribe(
      (data) => {
        this.phone = data;
      }
    );
  }
}
