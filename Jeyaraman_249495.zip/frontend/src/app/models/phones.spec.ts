import { Phones } from './phones';

describe('Phones', () => {
  it('should create an instance', () => {
    expect(new Phones()).toBeTruthy();
  });
});
