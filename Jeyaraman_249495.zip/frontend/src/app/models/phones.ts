export class Phones {
  cId : number;
  FirstName : string;
  LastName : string;
  Mobile : number;
  Mail : string;
  DateOfBirth : Date;
  Gender : string;
  Group : string;

}
