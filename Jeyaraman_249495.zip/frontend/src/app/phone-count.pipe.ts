import { Pipe, PipeTransform } from '@angular/core';
import { Phones } from './models/phones';

@Pipe({
  name: 'phonecount'
})
export class PhoneCountPipe implements PipeTransform {

  transform(value: Phones[], field?: string, fieldValue?: string): Number {
    let result = 0;
    
    if (value) {
      if (!field) {
        result = value.length;
      }
      else if (field.toLowerCase() == "gender") {
        value.forEach(p => {
          if (p.Gender.toLowerCase() == fieldValue.toLowerCase()) {
            result++;
          }
        });
      }
      else if (field.toLowerCase() == "group") {
        value.forEach(p => {
          if (p.Group.toLowerCase() == fieldValue.toLowerCase()) {
            result++;
          }
        });
      }
    }

    return result;
  }
}

